# Lab 4 – VibeCoding: Submission

| | |
|---|---|
| **Name** | Shriya Vasundhara Singh |
| **SRN** | PES1UG24AM269 |
| **GitHub** | [vasun26shriya](https://github.com/vasun26shriya) |
| **Assigned repo** | `SETAPESU26/30_donkeykong` (Donkey Kong Repair Lab) |
| **Tool used** | Claude (Anthropic) |

> Note: the assignment sheet lists this repo against `PES1UG23AM269`; it was matched on the `AM269` part of the SRN.

## Deliverables (all inside `Lab-4/`)

- [x] `videos/before_fix.mp4` – 10 s of gameplay **before** any changes (barrels take ladders ~70% of the time)
- [x] `videos/after_fix.mp4` – 10 s of gameplay **after** all changes (ladders ~30%, warm background, floating `+100`/`+200` labels, 2x score)
- [x] `game.py` – updated code
- [x] `chat_history/Lab4_Chat_History.pdf` – chat history with Claude

## What was changed (one commit per task)

| Commit | Task | Change |
|---|---|---|
| Task 1 | Fix ladder-descent bug | `random.random() < 0.7` → `< 0.3` in `Barrel.update` (measured: 70.0% → 30.0% over 4,000 simulated barrels) |
| Task 2 | `theme_color(score)` | Background warms from navy `(15,15,25)` to ember red `(90,30,20)` as score climbs to 1000; `None` at score 0 |
| Task 3 | `on_barrel_jumped(player, barrel)` | Spawns a floating label at the barrel that drifts up and fades out (`update_floating_labels` / `draw_floating_labels` helpers hooked into the main loop) |
| Task 4 | `score_multiplier(score)` | Returns `2` once score ≥ 300 (else `None`); the floating label shows the points actually awarded (`+100` / `+200`) |

## About the videos

The two clips are rendered from the real `game.py` main loop by `video_tools/record_demo.py`, which runs the game headlessly at a fixed 60 FPS and feeds it scripted keyboard input (a small bot that stands on the middle platform and hops over barrels), because the clips were produced on a machine without a display. The script is included for transparency. Run `python game.py` to play the game yourself.

## Run

```bash
pip install pygame
python game.py
```
