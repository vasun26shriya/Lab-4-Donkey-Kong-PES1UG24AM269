"""Headless recorder for the Donkey Kong lab videos.

Runs the *real* game.py main loop with a fake clock (fixed 1/60 s steps) and a
small scripted "player" that supplies keyboard input, and pipes every rendered
frame to ffmpeg. This lets the 10-second before/after clips be produced on a
machine without a display.

Usage:
    python record_demo.py <out.mp4> [--warmup SECONDS] [--seconds SECONDS] [--seed N]

`--warmup` runs the game (unrecorded) first so barrels are already flowing and
the bot has some score when recording begins.
"""
import argparse
import importlib.util
import os
import random
import subprocess
import sys

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

import pygame  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
GAME_PATH = os.path.join(HERE, "..", "game.py")
FPS = 60
JUMP_DX = (22, 28)
PLACE_X = 250  # where on platform 2 the bot stands (>80px below platform 3 so jumps do not land on it)


def load_game(path):
    spec = importlib.util.spec_from_file_location("game", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules["game"] = module
    spec.loader.exec_module(module)
    return module


class Bot:
    """Stands on the middle platform of the level and hops over oncoming barrels."""

    def __init__(self, game):
        self.game = game
        self.jump_next = False

    def keys(self):
        class Keys(dict):
            def __missing__(self, key):
                return 0
        return Keys()

    def step(self, player, barrels):
        g = self.game
        # Teleport onto platform 2 once so barrels reach the player quickly;
        # after that the bot only walks and jumps like a human would.
        if abs(player.pos.x - 40) < 1 and abs(player.pos.y - g.PLATFORMS[0][2]) < 1:
            self.placed = False  # just (re)spawned: hop back onto the middle platform
        if getattr(self, "placed", False) is False:
            player.pos.update(PLACE_X, g.platform_y(g.PLATFORMS[2], PLACE_X))
            player.on_ground = True
            self.placed = True
        self.jump_next = False
        if player.on_ground and player.ladder is None:
            for b in barrels:
                if b.plat == 2 and b.ladder is None:
                    dx = b.pos.x - player.pos.x
                    # The game only awards the jump bonus while the player is
                    # <40px above the barrel, so the bot jumps just before the
                    # barrel arrives (barrels on this platform roll leftwards).
                    if JUMP_DX[0] <= dx <= JUMP_DX[1] and abs(b.pos.y - player.pos.y + g.BARREL_R) < 4:
                        self.jump_next = True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("out")
    ap.add_argument("--warmup", type=float, default=0.0)
    ap.add_argument("--seconds", type=float, default=10.0)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--game", default=GAME_PATH)
    ap.add_argument("--log", default="", help="write 'frame,score,lives,labels' per frame to this CSV (for picking a good clip)")
    ap.add_argument("--caption", default="", help="small label drawn at the bottom of every frame")
    args = ap.parse_args()

    random.seed(args.seed)
    game = load_game(args.game)
    pygame.init()
    screen = pygame.display.set_mode((game.WIDTH, game.HEIGHT))
    total_frames = int((args.warmup + args.seconds) * FPS)
    record_from = int(args.warmup * FPS)
    state = {"frame": 0}
    bot = Bot(game)
    log = open(args.log, "w") if args.log else None

    ffmpeg = subprocess.Popen(
        ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24",
         "-s", f"{game.WIDTH}x{game.HEIGHT}", "-r", str(FPS), "-i", "-",
         "-c:v", "libx264", "-pix_fmt", "yuv420p", args.out],
        stdin=subprocess.PIPE,
    )

    # --- fake clock: every tick is exactly 1/60 s of game time ---------------
    class FakeClock:
        def tick(self, fps=0):
            return 1000 // FPS
    pygame.time.Clock = FakeClock

    # --- scripted input -------------------------------------------------------
    real_flip = pygame.display.flip
    pending = []

    def fake_get_pressed():
        return bot.keys()

    def fake_event_get():
        events, pending[:] = list(pending), []
        if state["frame"] >= total_frames:
            events.append(pygame.event.Event(pygame.QUIT))
        return events

    pygame.key.get_pressed = fake_get_pressed
    pygame.event.get = fake_event_get

    # Capture the player/barrels by wrapping draw_scene (called once per frame).
    real_draw = game.draw_scene

    def draw_hook(screen_, font, player, barrels, score, lives, st):
        bot.step(player, barrels)
        if st != "play" and state["frame"] % 90 == 0:
            pending.append(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_r))
        if bot.jump_next:
            pending.append(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_SPACE))
        real_draw(screen_, font, player, barrels, score, lives, st)
        if args.caption:
            cap = font.render(args.caption, True, (150, 220, 150))
            screen_.blit(cap, (10, game.HEIGHT - 26))
        if state["frame"] >= record_from:
            ffmpeg.stdin.write(pygame.image.tostring(screen_, "RGB"))
        if log is not None:
            log.write(f"{state['frame']},{score},{lives},{len(getattr(game, 'FLOATING_LABELS', []))}\n")
        state["frame"] += 1
        state["score"], state["lives"], state["st"] = score, lives, st

    game.draw_scene = draw_hook
    real_flip()
    game.main()
    ffmpeg.stdin.close()
    ffmpeg.wait()
    print("wrote", args.out, "| final score", state.get("score"), "lives", state.get("lives"))


if __name__ == "__main__":
    main()
